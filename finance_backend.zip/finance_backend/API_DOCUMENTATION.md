# Finance Dashboard Backend API Documentation

## Overview
A comprehensive Django REST API backend for a finance dashboard system with role-based access control, user management, and financial analytics.

**Base URL**: `http://127.0.0.1:8000/api/`

**Authentication**: Role-based via headers (for testing) or Token authentication

## Headers Required for Testing
Add these headers to your Postman requests:
- `Role`: `viewer` | `analyst` | `admin` (required for all requests)
- `Content-Type`: `application/json` (for POST/PUT requests)

## API Endpoints

### 🔐 Authentication & User Management

#### Create User (Admin Only)
```
POST /api/auth/register/
Headers:
  Role: admin
  Content-Type: application/json

Body (raw JSON):
{
  "username": "analyst1",
  "email": "analyst1@example.com", 
  "first_name": "Analyst",
  "last_name": "One",
  "password": "analyst123",
  "role": "analyst",
  "status": "active"
}

Success Response (201):
{
  "message": "User created successfully",
  "data": {
    "id": 3,
    "username": "analyst1",
    "email": "analyst1@example.com",
    "first_name": "Analyst", 
    "last_name": "One",
    "role": "analyst",
    "status": "active"
  }
}
```

#### Login User
```
POST /api/auth/login/
Headers:
  Role: admin
  Content-Type: application/json

Body (raw JSON):
{
  "username": "admin",
  "password": "admin123"
}

Success Response (200):
{
  "message": "Login successful",
  "token": "abc123token...",
  "user": {
    "id": 1,
    "username": "admin",
    "email": "admin@example.com",
    "role": "admin",
    "status": "active"
  }
}
```

#### List All Users (Admin Only)
```
GET /api/users/
Headers:
  Role: admin

Success Response (200):
{
  "count": 2,
  "data": [
    {
      "id": 1,
      "username": "admin",
      "email": "admin@example.com",
      "role": "admin",
      "status": "active"
    },
    {
      "id": 3,
      "username": "analyst1",
      "email": "analyst1@example.com", 
      "role": "analyst",
      "status": "active"
    }
  ]
}
```

#### Get/Update/Delete User (Admin Only)
```
GET /api/users/{id}/
PUT /api/users/{id}/
DELETE /api/users/{id}/
Headers:
  Role: admin
```

### 💰 Transaction Management

#### Get All Transactions
```
GET /api/transactions/
Headers:
  Role: viewer | analyst | admin

Query Parameters (optional):
  ?category=food
  &type=expense
  &start_date=2026-04-01
  &end_date=2026-04-30

Success Response (200):
{
  "count": 3,
  "data": [
    {
      "id": 1,
      "amount": 5000.0,
      "type": "income",
      "category": "salary",
      "date": "2026-04-01",
      "description": "Monthly salary",
      "created_by": null,
      "created_at": "2026-04-03T12:00:00Z"
    }
  ]
}
```

#### Create Transaction (Admin Only)
```
POST /api/transactions/
Headers:
  Role: admin
  Content-Type: application/json

Body (raw JSON):
{
  "amount": 1500.50,
  "type": "expense",
  "category": "food", 
  "date": "2026-04-03",
  "description": "Restaurant dinner"
}

Success Response (201):
{
  "message": "Transaction created successfully",
  "data": {
    "id": 3,
    "amount": 1500.5,
    "type": "expense",
    "category": "food",
    "date": "2026-04-03",
    "description": "Restaurant dinner",
    "created_by": null,
    "created_at": "2026-04-03T12:30:00Z"
  }
}
```

#### Get/Update/Delete Transaction
```
GET /api/transactions/{id}/
PUT /api/transactions/{id}/
DELETE /api/transactions/{id}/
Headers:
  Role: viewer (GET only) | analyst (GET only) | admin (all)
```

### 📊 Dashboard & Analytics

#### Dashboard Summary
```
GET /api/dashboard/
Headers:
  Role: viewer | analyst | admin

Success Response (200):
{
  "total_income": 10000.0,
  "total_expense": 1500.5,
  "net_balance": 8499.5,
  "category_breakdown": [
    {
      "category": "salary",
      "total": 10000.0
    },
    {
      "category": "food", 
      "total": 1500.5
    }
  ],
  "recent_transactions": [
    {
      "id": 3,
      "amount": 1500.5,
      "type": "expense",
      "category": "food",
      "date": "2026-04-03",
      "description": "Restaurant dinner"
    }
  ]
}
```

#### Analytics Trends
```
GET /api/analytics/trends/
Headers:
  Role: viewer | analyst | admin

Success Response (200):
{
  "monthly_trends": [
    {
      "month": "2026-04",
      "type": "income", 
      "total_amount": 10000.0,
      "count": 2
    },
    {
      "month": "2026-04",
      "type": "expense",
      "total_amount": 1500.5,
      "count": 1
    }
  ],
  "weekly_trends": [
    {
      "week": "2026-13",
      "type": "income",
      "total_amount": 10000.0,
      "count": 2
    }
  ],
  "category_trends": [
    {
      "category": "salary",
      "type": "income",
      "total_amount": 10000.0,
      "count": 1
    }
  ]
}
```

## 🚦 Permission Matrix

| Endpoint | Viewer | Analyst | Admin |
|----------|--------|---------|-------|
| `/api/dashboard/` | ✅ GET | ✅ GET | ✅ GET |
| `/api/analytics/trends/` | ✅ GET | ✅ GET | ✅ GET |
| `/api/transactions/` | ✅ GET | ✅ GET | ✅ GET, POST |
| `/api/transactions/{id}/` | ✅ GET | ✅ GET | ✅ GET, PUT, DELETE |
| `/api/auth/login/` | ✅ POST | ✅ POST | ✅ POST |
| `/api/auth/register/` | ❌ | ❌ | ✅ POST |
| `/api/users/` | ❌ | ❌ | ✅ GET |
| `/api/users/{id}/` | ❌ | ❌ | ✅ GET, PUT, DELETE |

## 🛠️ Postman Setup

### 1. Environment Variables
Create environment variables in Postman:
```
base_url: http://127.0.0.1:8000/api
user_role: admin
```

### 2. Collection Setup
Create a collection with these default headers:
```
Role: {{user_role}}
Content-Type: application/json
```

### 3. Example Requests

#### Create Admin User
```http
POST {{base_url}}/auth/register/
{
  "username": "admin",
  "email": "admin@example.com", 
  "password": "admin123",
  "role": "admin",
  "status": "active"
}
```

#### Create Sample Transaction
```http
POST {{base_url}}/transactions/
{
  "amount": 2500.0,
  "type": "income",
  "category": "freelance",
  "date": "2026-04-03",
  "description": "Web development project"
}
```

#### Get Dashboard Data
```http
GET {{base_url}}/dashboard/
```

## ❌ Error Responses

### Permission Denied (403)
```json
{
  "error": "Permission denied"
}
```

### Validation Error (400)
```json
{
  "username": ["User with this username already exists."],
  "amount": ["Amount must be greater than 0"]
}
```

### Not Found (404)
```json
{
  "error": "Transaction not found"
}
```

### Authentication Error (401)
```json
{
  "error": "Invalid credentials"
}
```

## 📝 Testing Checklist

- [ ] Create admin user
- [ ] Create analyst and viewer users
- [ ] Test dashboard with different roles
- [ ] Create transactions as admin
- [ ] Try creating transactions as viewer (should fail)
- [ ] Test transaction filtering
- [ ] Verify analytics trends data
- [ ] Test user management endpoints
- [ ] Validate error handling

## 🔧 Server Setup

1. **Start the server**:
   ```bash
   python manage.py runserver
   ```

2. **Access points**:
   - API Base URL: `http://127.0.0.1:8000/api/`
   - Admin Panel: `http://127.0.0.1:8000/admin/`
   - API Root: `http://127.0.0.1:8000/` (redirects to dashboard)

3. **Default Admin** (if created):
   - Username: `admin`
   - Password: `admin123`
   - Email: `admin@example.com`
