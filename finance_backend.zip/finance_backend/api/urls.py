# from django.urls import path
# from .views import get_transactions, transaction_detail
# from api.views import home

# urlpatterns = [
#     path('', home),
#     path('transactions/', get_transactions),
#     path('transactions/<int:pk>/', transaction_detail)
# ]

from django.urls import path
from .views import (
    get_transactions, transaction_detail, dashboard_summary,
    register_user, login_user, user_detail, user_list,
    analytics_trends, home_view
)

urlpatterns = [
    # 🏠 Root
    path('', home_view, name='home'),
    
    # 💰 Transactions
    path('transactions/', get_transactions),
    path('transactions/<int:pk>/', transaction_detail),
    
    # 📊 Dashboard & Analytics
    path('dashboard/', dashboard_summary),
    path('analytics/trends/', analytics_trends),
    
    # 🔐 User Management
    path('auth/login/', login_user),
    path('auth/register/', register_user),
    path('users/', user_list),
    path('users/<int:pk>/', user_detail),
]