from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.db.models import Sum
from datetime import datetime
from django.shortcuts import redirect
from django.contrib.auth import authenticate
from rest_framework.authtoken.models import Token

from .models import Transaction, FinanceUser
from .serializers import TransactionSerializer, UserSerializer


# ROLE CHECK (from headers)
def get_user_role(request):
    return request.headers.get('Role', 'viewer').lower()


# 🔐 PERMISSION CHECK HELPER
def is_admin(role):
    return role == 'admin'


def can_view(role):
    return role in ['admin', 'analyst', 'viewer']


# ✅ LIST + CREATE
@api_view(['GET', 'POST'])
def get_transactions(request):

    role = get_user_role(request)

    # 📄 GET TRANSACTIONS
    if request.method == 'GET':

        if not can_view(role):
            return Response({"error": "Permission denied"}, status=403)

        transactions = Transaction.objects.all()

        # 🔍 FILTERS
        category = request.GET.get('category')
        t_type = request.GET.get('type')
        start_date = request.GET.get('start_date')
        end_date = request.GET.get('end_date')

        if category:
            transactions = transactions.filter(category=category)

        if t_type:
            transactions = transactions.filter(type=t_type)

        # 📅 DATE FILTER
        if start_date:
            transactions = transactions.filter(date__gte=start_date)

        if end_date:
            transactions = transactions.filter(date__lte=end_date)

        serializer = TransactionSerializer(transactions, many=True)
        return Response({
            "count": len(serializer.data),
            "data": serializer.data
        })

    # ➕ CREATE TRANSACTION
    elif request.method == 'POST':

        if not is_admin(role):
            return Response({"error": "Only admin can create"}, status=403)

        serializer = TransactionSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response({
                "message": "Transaction created successfully",
                "data": serializer.data
            }, status=201)

        return Response(serializer.errors, status=400)


# ✅ RETRIEVE + UPDATE + DELETE
@api_view(['GET', 'PUT', 'DELETE'])
def transaction_detail(request, pk):

    role = get_user_role(request)

    try:
        transaction = Transaction.objects.get(pk=pk)
    except Transaction.DoesNotExist:
        return Response({"error": "Transaction not found"}, status=404)

    # 📄 GET SINGLE
    if request.method == 'GET':

        if not can_view(role):
            return Response({"error": "Permission denied"}, status=403)

        serializer = TransactionSerializer(transaction)
        return Response(serializer.data)

    # ✏️ UPDATE
    elif request.method == 'PUT':

        if not is_admin(role):
            return Response({"error": "Only admin can update"}, status=403)

        serializer = TransactionSerializer(transaction, data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response({
                "message": "Updated successfully",
                "data": serializer.data
            })

        return Response(serializer.errors, status=400)

    # ❌ DELETE
    elif request.method == 'DELETE':

        if not is_admin(role):
            return Response({"error": "Only admin can delete"}, status=403)

        transaction.delete()
        return Response({"message": "Deleted successfully"}, status=204)


# 📊 DASHBOARD SUMMARY API
@api_view(['GET'])
def dashboard_summary(request):

    role = get_user_role(request)

    if not can_view(role):
        return Response({"error": "Permission denied"}, status=403)

    total_income = Transaction.objects.filter(type='income').aggregate(Sum('amount'))['amount__sum'] or 0
    total_expense = Transaction.objects.filter(type='expense').aggregate(Sum('amount'))['amount__sum'] or 0

    # 📊 CATEGORY BREAKDOWN
    category_data = Transaction.objects.values('category').annotate(total=Sum('amount'))

    # 📅 RECENT 5 TRANSACTIONS
    recent_transactions = Transaction.objects.order_by('-date')[:5]
    recent_serializer = TransactionSerializer(recent_transactions, many=True)

    return Response({
        "total_income": total_income,
        "total_expense": total_expense,
        "net_balance": total_income - total_expense,
        "category_breakdown": category_data,
        "recent_transactions": recent_serializer.data
    })


# 🏠 HOME VIEW - Root URL handler
def home_view(request):
    """Simple home view that redirects to API dashboard"""
    return redirect('api/dashboard/')


# 🔐 USER MANAGEMENT VIEWS
@api_view(['POST'])
def register_user(request):
    """Register a new user (admin only)"""
    role = get_user_role(request)
    
    if not is_admin(role):
        return Response({"error": "Only admin can create users"}, status=403)
    
    serializer = UserSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        return Response({
            "message": "User created successfully",
            "data": UserSerializer(user).data
        }, status=201)
    
    return Response(serializer.errors, status=400)


@api_view(['POST'])
def login_user(request):
    """Login user and return token"""
    username = request.data.get('username')
    password = request.data.get('password')
    
    if not username or not password:
        return Response({"error": "Username and password required"}, status=400)
    
    user = authenticate(username=username, password=password)
    if user:
        if user.status != 'active':
            return Response({"error": "Account is inactive"}, status=403)
        
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            "message": "Login successful",
            "token": token.key,
            "user": UserSerializer(user).data
        })
    
    return Response({"error": "Invalid credentials"}, status=401)


@api_view(['GET', 'PUT', 'DELETE'])
def user_detail(request, pk):
    """Get, update or delete user (admin only)"""
    role = get_user_role(request)
    
    if not is_admin(role):
        return Response({"error": "Only admin can manage users"}, status=403)
    
    try:
        user = FinanceUser.objects.get(pk=pk)
    except FinanceUser.DoesNotExist:
        return Response({"error": "User not found"}, status=404)
    
    if request.method == 'GET':
        serializer = UserSerializer(user)
        return Response(serializer.data)
    
    elif request.method == 'PUT':
        serializer = UserSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            updated_user = serializer.save()
            return Response({
                "message": "User updated successfully",
                "data": UserSerializer(updated_user).data
            })
        return Response(serializer.errors, status=400)
    
    elif request.method == 'DELETE':
        user.delete()
        return Response({"message": "User deleted successfully"}, status=204)


@api_view(['GET'])
def user_list(request):
    """List all users (admin only)"""
    role = get_user_role(request)
    
    if not is_admin(role):
        return Response({"error": "Only admin can view users"}, status=403)
    
    users = FinanceUser.objects.all()
    serializer = UserSerializer(users, many=True)
    return Response({
        "count": len(serializer.data),
        "data": serializer.data
    })


# 📈 ENHANCED ANALYTICS
@api_view(['GET'])
def analytics_trends(request):
    """Get monthly/weekly trends analytics"""
    role = get_user_role(request)
    
    if not can_view(role):
        return Response({"error": "Permission denied"}, status=403)
    
    # 📅 MONTHLY TRENDS
    from django.db.models import Count
    from datetime import timedelta
    
    monthly_data = Transaction.objects.extra(
        select={'month': 'strftime("%%Y-%%m", date)'}
    ).values('month', 'type').annotate(
        total_amount=Sum('amount'),
        count=Count('id')
    ).order_by('month')
    
    # 📊 WEEKLY TRENDS (last 12 weeks)
    weeks_ago = 12
    weekly_data = Transaction.objects.filter(
        date__gte=datetime.now().date() - timedelta(weeks=weeks_ago)
    ).extra(
        select={'week': 'strftime("%%Y-%%W", date)'}
    ).values('week', 'type').annotate(
        total_amount=Sum('amount'),
        count=Count('id')
    ).order_by('week')
    
    # 📈 CATEGORY TRENDS
    category_trends = Transaction.objects.values('category', 'type').annotate(
        total_amount=Sum('amount'),
        count=Count('id')
    ).order_by('-total_amount')
    
    return Response({
        "monthly_trends": list(monthly_data),
        "weekly_trends": list(weekly_data),
        "category_trends": list(category_trends)
    })