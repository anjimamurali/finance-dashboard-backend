# from rest_framework import serializers
# from .models import Transaction
from rest_framework import serializers
from .models import Transaction, FinanceUser

class UserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    
    class Meta:
        model = FinanceUser
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'role', 'status', 'password']
        extra_kwargs = {
            'password': {'write_only': True}
        }
    
    def create(self, validated_data):
        password = validated_data.pop('password', None)
        user = FinanceUser.objects.create_user(**validated_data)
        if password:
            user.set_password(password)
        return user
    
    def validate_role(self, value):
        valid_roles = ['viewer', 'analyst', 'admin']
        if value not in valid_roles:
            raise serializers.ValidationError(f"Role must be one of: {', '.join(valid_roles)}")
        return value
    
    def validate_status(self, value):
        valid_statuses = ['active', 'inactive']
        if value not in valid_statuses:
            raise serializers.ValidationError(f"Status must be one of: {', '.join(valid_statuses)}")
        return value

class TransactionSerializer(serializers.ModelSerializer):
    created_by_username = serializers.CharField(source='created_by.username', read_only=True)
    
    class Meta:
        model = Transaction
        fields = ['id', 'amount', 'type', 'category', 'date', 'description', 'created_by', 'created_by_username', 'created_at', 'updated_at']
        read_only_fields = ['created_by', 'created_at', 'updated_at']

    def validate_amount(self, value):
        if value <= 0:
            raise serializers.ValidationError("Amount must be greater than 0")
        return value

    def validate_type(self, value):
        valid_types = ['income', 'expense']
        if value not in valid_types:
            raise serializers.ValidationError(f"Type must be one of: {', '.join(valid_types)}")
        return value