from django.contrib import admin
from .models import Transaction, FinanceUser

@admin.register(FinanceUser)
class FinanceUserAdmin(admin.ModelAdmin):
    list_display = ['username', 'email', 'role', 'status', 'created_at']
    list_filter = ['role', 'status', 'created_at']
    search_fields = ['username', 'email']
    readonly_fields = ['created_at', 'updated_at']

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ['type', 'amount', 'category', 'date', 'created_by', 'created_at']
    list_filter = ['type', 'category', 'date', 'created_by']
    search_fields = ['category', 'description']
    date_hierarchy = 'date'
    
    readonly_fields = ['created_at', 'updated_at']